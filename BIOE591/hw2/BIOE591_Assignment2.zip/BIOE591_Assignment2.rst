
BIOE 591: Ecological Modeling Homework Assignment 2
===================================================

Author: Tony Chang

Date: 09/17/14

Abstract: Solutions to BIOE1 assignment 2 written in Python 3.4

Dependencies: Python 3.4

Pre-exercise
------------

.. code:: python

    #declare the constants
    stock_terrestrial_biomass = 5.6e17
    terrestrial_npp = 5e16
    stock_marine_biomass = 2e15
    marine_npp = 2.5e16
.. code:: python

    rt_terrestrial = stock_terrestrial_biomass/terrestrial_npp
    rt_marine = stock_marine_biomass/marine_npp
    print('T_terrestrial = %.1f yr \t T_marine = %.2f yr' %(rt_terrestrial, rt_marine))

.. parsed-literal::

    T_terrestrial = 11.2 yr 	 T_marine = 0.08 yr


Exercise 1
----------

*Exercise 1: Suppose that the average residence time (ignoring
respiratory pathways) of carbon in the phytoplankton in a lake is two
weeks. Zooplankton in the lake, grazing upon the phytoplankton, consume
40% of the net primary productivity and have an incorporation efficiency
of 25% (i.e., 25% of the phytoplankton biomass they eat is incorporated
into zooplankton biomass). In other words, the net productivity of the
zooplankton is 0.25 x 0.40 or 10% of the npp of the algae. If the
average residence time (ignoring respiratory pathways) of carbon in
zooplankton biomass is six months, estimate the ratio of the average
biomass of the zooplankton population to that of the phytoplankton
population in the lake. Figure II-3 illustrates the flows in and out of
the two stocks of plankton.*

.. code:: python

    from IPython.core.display import Image
    Image(filename="/media/shared/Courses/BIOE591/hw2/ScanFigII3.jpg")



.. image:: output_6_0.jpeg



Since we don't know the gross primary productivity in the lake, we can
just use some arbitrary value (G=1). This will not matter since we will
be considering a ratio of zooplankton mass to phytoplankton mass.

Given the parameters described in the text, we can calculate the stock
of zooplankton as a function of the NPP from phytoplankton below:

.. math:: M_{zoo} = NPP_{phy} \cdot I \cdot C \cdot rt_{zoo} 

Where :math:`I` is the incorporation efficiency, :math:`C` is the
percent of phytoplankton consumed, and :math:`rt_{zoo}` is the residence
time for zooplankton. Phytoplankton stock can simply be calculated with
the known residence time :math:`rt_{phy}`.

.. math:: M_{phy} = NPP_{phy} \cdot rt_{phy} 

So in calculating the ratio of zooplankton mass and phytoplankton mass,
we need only consider the residence times for both zooplankton and
phytoplankton, and the efficiency at which zooplankton incorporates
phytoplankton:

.. math:: r = \frac{M_{zoo}}{M_{phy}} = \frac{I \cdot C \cdot rt_{zoo}}{rt_{phy}} 

.. code:: python

    yr_wk = (1/52.1775)
    rt_phy = 2 * yr_wk #2 week residence time for phytoplankton
    rt_zoo = 0.5 #6 month residence time for zooplankton
    G = 1  #gross primary productivity g(C)/yr of phytoplankton (use arbitrary 1 value)
    R = 0 #resiration rate 
    N = G - R #net primary productivity
    M_P = N * rt_phy # stock of phytoplankton
    I = 0.25 #incorporation efficiency of phytoplankton by zooplankton
    C = 0.4 #percent of phytoplankton consumed by zooplankton
    H = N * I * C #input net primary productivity of zooplankton
    M_Z = H * rt_zoo
    
    ratio = M_Z/M_P
.. code:: python

    #print the results
    print('The average mass ratio of zooplankton to phytoplankton is: %.1f' %(ratio))

.. parsed-literal::

    The average mass ratio of zooplankton to phytoplankton is: 1.3


Due to the longer residence time of zooplankton over the course of a
year, there will be ~1.3 mass of zooplankton to every one mass of
phytoplankton in the lake stock every year under the given zooplankton
consumption/incorporation efficiency and residence times.
